% Skript: JLoad_with_Friction.m

% Lese die Trace-Daten mit Reibung ein [cite: 568]
[data, names] = load_traces('JLoadAndFriction.trace');
% Extrahiere die Zeitachse [cite: 512]
t_ms = data(:, 1);
% Bestimme die Abtastzeit T
T = (t_ms(2) - t_ms(1)) / 1000;
% Extrahiere omega und konvertiere in rad/s [cite: 569]
omega = data(:, 2) * (pi / 180);
% Extrahiere Iq und konvertiere in A [cite: 569]
Iq = data(:, 3) / 1000;
% Berechne die Winkelbeschleunigung [cite: 570]
alpha = num_derivative(omega, T);
% Berechne das Drehmoment [cite: 570]
M_motor = torqueconstant(Iq) .* Iq;

% Zeichne die Signale vor der Filterung analog zu Arbeitsauftrag 5 [cite: 575]
figure;
subplot(3,1,1); plot(t_ms, omega); hold on; ylabel('omega [rad/s]'); grid on;
subplot(3,1,2); plot(t_ms, alpha); hold on; ylabel('alpha [rad/s^2]'); grid on;
subplot(3,1,3); plot(t_ms, M_motor); hold on; ylabel('M_{motor} [Nm]'); grid on;

% --- Beginn Arbeitsauftrag 8 ---

% Finde Indizes aller Werte, bei denen der Betrag von omega >= 20 rad/s ist [cite: 586]
valid_idx = find(abs(omega) >= 20);

% Filtere die Zeitachse für synchrone Darstellung [cite: 587]
t_sync = t_ms(valid_idx);
% Filtere das Geschwindigkeitssignal [cite: 586]
omega_filt = omega(valid_idx);
% Filtere das Beschleunigungssignal [cite: 586]
alpha_filt = alpha(valid_idx);
% Filtere das Drehmomentsignal [cite: 586]
M_motor_filt = M_motor(valid_idx);

% Zeichne die gefilterten Signale zur Überprüfung der Synchronisation (in rot) [cite: 593]
subplot(3,1,1); plot(t_sync, omega_filt, 'r.');
subplot(3,1,2); plot(t_sync, alpha_filt, 'r.');
subplot(3,1,3); plot(t_sync, M_motor_filt, 'r.');

% --- Beginn Arbeitsauftrag 9 ---

% Erstelle die Matrix A mit den Spalten alpha, omega und sign(omega) [cite: 598, 599, 600]
A = [alpha_filt, omega_filt, sign(omega_filt)];

% Erstelle den Vektor b aus dem gefilterten Drehmoment [cite: 598, 599]
b = M_motor_filt;

% Löse das überbestimmte Gleichungssystem (Methode der kleinsten Fehlerquadrate) [cite: 96, 603]
x = A \ b;

% Extrahiere J aus dem Lösungsvektor (Einheit: kg*m^2) [cite: 605]
J_est = x(1);
% Extrahiere den geschwindigkeitsabhängigen Reibkoeffizienten [cite: 605]
K_Fric_omega = x(2);
% Extrahiere den konstanten Reibkoeffizienten [cite: 605]
K_Fric_0 = x(3);

% Berechne den Fehlervektor e = A*x - b [cite: 86]
e = A * x - b;
% Berechne das quadratische Fehlermaß E [cite: 89, 604]
E = sum(e.^2);

% Gib die Ergebnisse und Einheiten in der Konsole aus [cite: 605]
disp(['J: ', num2str(J_est), ' kg*m^2']);
disp(['K_Fric_omega: ', num2str(K_Fric_omega), ' Nm/(rad/s)']);
disp(['K_Fric_0: ', num2str(K_Fric_0), ' Nm']);
disp(['Fehler E: ', num2str(E)]);

% Berechne das geschätzte Drehmoment für ALLE Zeitpunkte (ungefiltert) [cite: 607, 613]
M_motor_est = J_est * alpha + K_Fric_omega * omega + K_Fric_0 * sign(omega);

% Zeichne das geschätzte Drehmoment in das dritte Subplot (grün) [cite: 614]
subplot(3,1,3); plot(t_ms, M_motor_est, 'g--');

% Definiere das Motorträgheitsmoment erneut (Wert aus Versuchsteil 1!) 
J_Motor = 0.0; % HIER WERT IN kg*m^2 EINTRAGEN

% Berechne J_Load in kg*cm^2 und gib es aus [cite: 615]
J_Load_kgcm2 = (J_est - J_Motor) * 10000;
disp(['Neues J_Load: ', num2str(J_Load_kgcm2), ' kg*cm^2']);